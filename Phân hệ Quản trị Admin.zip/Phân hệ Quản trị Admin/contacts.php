<?php
/**
 * admin/contacts.php - Quản lý Ý Kiến Đóng Góp / Phản Hồi Từ Người Dùng
 */
$adminTitle = "Hộp Thư Liên Hệ";
include_once __DIR__ . '/header.php';

// Đổi trạng thái đã đọc
if (isset($_GET['mark_read'])) {
    $cId = (int)$_GET['mark_read'];
    $pdo->prepare("UPDATE contacts SET status = 'read' WHERE id = ?")->execute([$cId]);
    header("Location: contacts.php");
    exit;
}

// Xóa tin nhắn
if (isset($_GET['delete'])) {
    $cId = (int)$_GET['delete'];
    $pdo->prepare("DELETE FROM contacts WHERE id = ?")->execute([$cId]);
    header("Location: contacts.php");
    exit;
}

$contacts = $pdo->query("SELECT * FROM contacts ORDER BY id DESC")->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold mb-1">Hộp Thư Liên Hệ & Phản Hồi</h3>
        <p class="text-muted small mb-0">Quản lý ý kiến đóng góp của người nghe gửi qua trang Liên Hệ</p>
    </div>
</div>

<div class="card bg-card border-secondary rounded-3">
    <div class="table-responsive">
        <table class="table table-dark-custom mb-0">
            <thead>
                <tr>
                    <th style="width: 50px;">ID</th>
                    <th>Người Gửi</th>
                    <th>Email</th>
                    <th>Tiêu Đề</th>
                    <th>Nội Dung</th>
                    <th>Thời Gian</th>
                    <th>Trạng Thái</th>
                    <th>Hành Động</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($contacts)): ?>
                    <tr><td colspan="8" class="text-center py-4 text-muted">Chưa có phản hồi nào.</td></tr>
                <?php else: ?>
                    <?php foreach ($contacts as $item): ?>
                        <tr class="<?= $item['status'] === 'unread' ? 'table-active' : '' ?>">
                            <td>#<?= $item['id'] ?></td>
                            <td class="fw-bold text-white"><?= htmlspecialchars($item['fullname']) ?></td>
                            <td><?= htmlspecialchars($item['email']) ?></td>
                            <td class="text-info"><?= htmlspecialchars($item['subject']) ?></td>
                            <td style="max-width: 300px;"><?= nl2br(htmlspecialchars($item['message'])) ?></td>
                            <td class="small text-muted"><?= date('d/m/Y H:i', strtotime($item['created_at'])) ?></td>
                            <td>
                                <?php if ($item['status'] === 'unread'): ?>
                                    <span class="badge bg-warning text-dark">Chưa đọc</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Đã xem</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($item['status'] === 'unread'): ?>
                                    <a href="contacts.php?mark_read=<?= $item['id'] ?>" class="btn btn-sm btn-outline-success me-1" title="Đánh dấu đã đọc">
                                        <i class="bi bi-check2"></i>
                                    </a>
                                <?php endif; ?>
                                <a href="contacts.php?delete=<?= $item['id'] ?>" class="btn btn-sm btn-outline-danger" title="Xóa" onclick="return confirm('Bạn có chắc chắn muốn xóa tin nhắn này?');">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include_once __DIR__ . '/footer.php'; ?>

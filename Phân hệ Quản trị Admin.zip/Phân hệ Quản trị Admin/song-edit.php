<?php
/**
 * admin/song-edit.php - Sửa thông tin bài hát (CRUD Update)
 */
$adminTitle = "Sửa Bài Hát";
include_once __DIR__ . '/header.php';

$song_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $pdo->prepare("SELECT * FROM songs WHERE id = ?");
$stmt->execute([$song_id]);
$song = $stmt->fetch();

if (!$song) {
    header("Location: songs.php");
    exit;
}

$error = '';
$success = '';

$artists = $pdo->query("SELECT * FROM artists ORDER BY name ASC")->fetchAll();
$categories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $artist_id = (int)($_POST['artist_id'] ?? 0);
    $category_id = (int)($_POST['category_id'] ?? 0);
    $duration = trim($_POST['duration'] ?? '03:30');
    $lyrics = trim($_POST['lyrics'] ?? '');

    $file_path = trim($_POST['file_path'] ?? $song['file_path']);
    $thumbnail = trim($_POST['thumbnail'] ?? $song['thumbnail']);

    // Upload audio nếu có file mới
    if (isset($_FILES['audio_file']) && $_FILES['audio_file']['error'] === UPLOAD_ERR_OK) {
        $audioFile = $_FILES['audio_file'];
        $ext = strtolower(pathinfo($audioFile['name'], PATHINFO_EXTENSION));
        $allowedAudio = ['mp3', 'wav', 'ogg', 'm4a'];
        if (in_array($ext, $allowedAudio)) {
            $newAudioName = 'song_' . time() . '_' . rand(100, 999) . '.' . $ext;
            if (move_uploaded_file($audioFile['tmp_name'], __DIR__ . '/../uploads/' . $newAudioName)) {
                $file_path = 'uploads/' . $newAudioName;
            }
        } else {
            $error = 'File nhạc không đúng định dạng (.mp3, .wav, .ogg)!';
        }
    }

    // Upload thumbnail nếu có ảnh mới
    if (isset($_FILES['thumb_file']) && $_FILES['thumb_file']['error'] === UPLOAD_ERR_OK) {
        $thumbFile = $_FILES['thumb_file'];
        $imgExt = strtolower(pathinfo($thumbFile['name'], PATHINFO_EXTENSION));
        $allowedImg = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
        if (in_array($imgExt, $allowedImg)) {
            $newImgName = 'thumb_' . time() . '_' . rand(100, 999) . '.' . $imgExt;
            if (move_uploaded_file($thumbFile['tmp_name'], __DIR__ . '/../uploads/' . $newImgName)) {
                $thumbnail = 'uploads/' . $newImgName;
            }
        }
    }

    if (empty($title) || empty($artist_id) || empty($category_id) || empty($file_path)) {
        $error = 'Vui lòng điền đầy đủ các thông tin bắt buộc!';
    } else {
        try {
            $stmtUpdate = $pdo->prepare("
                UPDATE songs 
                SET title = ?, artist_id = ?, category_id = ?, file_path = ?, thumbnail = ?, duration = ?, lyrics = ? 
                WHERE id = ?
            ");
            $stmtUpdate->execute([$title, $artist_id, $category_id, $file_path, $thumbnail, $duration, $lyrics, $song_id]);
            $success = 'Cập nhật bài hát thành công!';
            
            // Reload lại thông tin
            $stmt->execute([$song_id]);
            $song = $stmt->fetch();
        } catch (PDOException $e) {
            $error = 'Lỗi cập nhật CSDL: ' . $e->getMessage();
        }
    }
}
?>

<div class="row justify-content-center">
    <div class="col-lg-9">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold mb-1">Cập Nhật Bài Hát #<?= $song['id'] ?></h3>
                <p class="text-muted small mb-0">Chỉnh sửa thông tin bài hát: <?= htmlspecialchars($song['title']) ?></p>
            </div>
            <a href="songs.php" class="btn btn-outline-custom btn-sm">
                <i class="bi bi-arrow-left me-1"></i> Quay lại danh sách
            </a>
        </div>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger mb-4"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="alert alert-success mb-4">
                <i class="bi bi-check-circle me-1"></i> <?= htmlspecialchars($success) ?>
                <a href="songs.php" class="alert-link ms-2">Về danh sách bài hát</a>
            </div>
        <?php endif; ?>

        <div class="card bg-card border-secondary p-4 rounded-3 shadow">
            <form action="song-edit.php?id=<?= $song['id'] ?>" method="POST" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-md-12">
                        <label class="form-label text-light">Tên bài hát <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control form-control-dark" required value="<?= htmlspecialchars($song['title']) ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-light">Ca sĩ / Nghệ sĩ <span class="text-danger">*</span></label>
                        <select name="artist_id" class="form-select form-select-dark" required>
                            <?php foreach ($artists as $a): ?>
                                <option value="<?= $a['id'] ?>" <?= ($song['artist_id'] == $a['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($a['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-light">Thể loại nhạc <span class="text-danger">*</span></label>
                        <select name="category_id" class="form-select form-select-dark" required>
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= $c['id'] ?>" <?= ($song['category_id'] == $c['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($c['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-light">Đường dẫn file MP3 (URL hiện tại)</label>
                        <input type="text" name="file_path" class="form-control form-control-dark" value="<?= htmlspecialchars($song['file_path']) ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-light">Thay thế file MP3 (Tải file mới)</label>
                        <input type="file" name="audio_file" class="form-control form-control-dark" accept=".mp3,.wav,.ogg">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-light">Đường dẫn ảnh Thumbnail</label>
                        <input type="text" name="thumbnail" class="form-control form-control-dark" value="<?= htmlspecialchars($song['thumbnail']) ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-light">Thay đổi ảnh Thumbnail</label>
                        <input type="file" name="thumb_file" class="form-control form-control-dark" accept="image/*">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label text-light">Thời lượng</label>
                        <input type="text" name="duration" class="form-control form-control-dark" value="<?= htmlspecialchars($song['duration']) ?>">
                    </div>

                    <div class="col-12">
                        <label class="form-label text-light">Lời bài hát (Lyrics)</label>
                        <textarea name="lyrics" class="form-control form-control-dark" rows="5"><?= htmlspecialchars($song['lyrics']) ?></textarea>
                    </div>

                    <div class="col-12 mt-4">
                        <button type="submit" class="btn btn-primary-custom px-4 py-2">
                            <i class="bi bi-save me-1"></i> Cập Nhật Thay Đổi
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include_once __DIR__ . '/footer.php'; ?>

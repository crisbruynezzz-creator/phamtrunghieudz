<?php
/**
 * admin/categories.php - Quản lý Thể loại nhạc (Thêm, Sửa, Xóa)
 */
$adminTitle = "Quản Lý Thể Loại";
include_once __DIR__ . '/header.php';

$error = '';
$success = '';

// Xử lý Xóa thể loại
if (isset($_GET['delete'])) {
    $delId = (int)$_GET['delete'];
    try {
        $stmtDel = $pdo->prepare("DELETE FROM categories WHERE id = ?");
        $stmtDel->execute([$delId]);
        $success = "Đã xóa thể loại thành công!";
    } catch (PDOException $e) {
        $error = "Không thể xóa thể loại đang có bài hát liên kết!";
    }
}

// Xử lý Thêm mới hoặc Sửa thể loại
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cat_id = isset($_POST['cat_id']) ? (int)$_POST['cat_id'] : 0;
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');

    if (empty($name)) {
        $error = "Vui lòng nhập tên thể loại!";
    } else {
        try {
            if ($cat_id > 0) {
                // Sửa
                $stmt = $pdo->prepare("UPDATE categories SET name = ?, description = ? WHERE id = ?");
                $stmt->execute([$name, $description, $cat_id]);
                $success = "Cập nhật thể loại thành công!";
            } else {
                // Thêm mới
                $stmt = $pdo->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
                $stmt->execute([$name, $description]);
                $success = "Thêm thể loại mới thành công!";
            }
        } catch (PDOException $e) {
            $error = "Lỗi CSDL (Có thể tên thể loại đã trùng lặp): " . $e->getMessage();
        }
    }
}

// Lấy danh sách thể loại kèm số lượng bài hát
$categories = $pdo->query("
    SELECT c.*, COUNT(s.id) AS total_songs 
    FROM categories c 
    LEFT JOIN songs s ON c.id = s.category_id 
    GROUP BY c.id 
    ORDER BY c.id DESC
")->fetchAll();

// Nếu click Sửa thì lấy dữ liệu thể loại đó
$editCat = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $stmtE = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
    $stmtE->execute([$editId]);
    $editCat = $stmtE->fetch();
}
?>

<div class="row g-4">
    <!-- Cột trái: Form Thêm / Sửa -->
    <div class="col-lg-4">
        <div class="card bg-card border-secondary p-4 rounded-3 shadow">
            <h5 class="fw-bold mb-3 text-white">
                <i class="bi bi-tag-fill me-2 text-warning"></i>
                <?= $editCat ? 'Cập Nhật Thể Loại' : 'Thêm Thể Loại Mới' ?>
            </h5>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger py-2 small mb-3"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <?php if (!empty($success)): ?>
                <div class="alert alert-success py-2 small mb-3"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>

            <form action="categories.php" method="POST">
                <?php if ($editCat): ?>
                    <input type="hidden" name="cat_id" value="<?= $editCat['id'] ?>">
                <?php endif; ?>

                <div class="mb-3">
                    <label class="form-label text-light">Tên thể loại <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control form-control-dark" placeholder="Ví dụ: Nhạc Rap / HipHop" required value="<?= htmlspecialchars($editCat['name'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label text-light">Mô tả thể loại</label>
                    <textarea name="description" class="form-control form-control-dark" rows="3" placeholder="Đặc điểm giai điệu..."><?= htmlspecialchars($editCat['description'] ?? '') ?></textarea>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary-custom flex-grow-1">
                        <?= $editCat ? 'Cập Nhật' : 'Thêm Mới' ?>
                    </button>
                    <?php if ($editCat): ?>
                        <a href="categories.php" class="btn btn-outline-custom">Hủy</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- Cột phải: Bảng danh sách thể loại -->
    <div class="col-lg-8">
        <div class="card bg-card border-secondary rounded-3">
            <div class="card-header bg-transparent border-secondary py-3">
                <h5 class="fw-bold mb-0 text-white"><i class="bi bi-grid-fill me-2 text-success"></i>Danh Sách Thể Loại</h5>
            </div>
            <div class="table-responsive">
                <table class="table table-dark-custom mb-0">
                    <thead>
                        <tr>
                            <th style="width: 60px;">ID</th>
                            <th>Tên Thể Loại</th>
                            <th>Mô Tả</th>
                            <th>Số Bài Hát</th>
                            <th>Hành Động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($categories)): ?>
                            <tr><td colspan="5" class="text-center py-4 text-muted">Chưa có thể loại nào.</td></tr>
                        <?php else: ?>
                            <?php foreach ($categories as $c): ?>
                                <tr>
                                    <td>#<?= $c['id'] ?></td>
                                    <td class="fw-bold text-white"><?= htmlspecialchars($c['name']) ?></td>
                                    <td class="small text-muted"><?= htmlspecialchars($c['description'] ?? 'Không có') ?></td>
                                    <td><span class="badge bg-secondary"><?= $c['total_songs'] ?> bài</span></td>
                                    <td>
                                        <a href="categories.php?edit=<?= $c['id'] ?>" class="btn btn-sm btn-outline-warning me-1" title="Sửa">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>
                                        <a href="categories.php?delete=<?= $c['id'] ?>" class="btn btn-sm btn-outline-danger" title="Xóa" onclick="return confirm('Bạn có chắc chắn muốn xóa thể loại này?');">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include_once __DIR__ . '/footer.php'; ?>

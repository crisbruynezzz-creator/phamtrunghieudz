<?php
/**
 * admin/song-delete.php - Xóa bài hát khỏi hệ thống (CRUD Delete)
 */
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/../config/database.php';

$song_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($song_id > 0) {
    try {
        $stmt = $pdo->prepare("DELETE FROM songs WHERE id = ?");
        $stmt->execute([$song_id]);
    } catch (PDOException $e) {
        die("Lỗi xóa bài hát: " . $e->getMessage());
    }
}

header("Location: songs.php?msg=deleted");
exit;
?>

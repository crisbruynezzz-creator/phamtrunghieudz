<?php
/**
 * admin/songs.php - Quản lý danh sách bài hát (CRUD)
 */
$adminTitle = "Quản Lý Bài Hát";
include_once __DIR__ . '/header.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

if (!empty($search)) {
    $stmt = $pdo->prepare("
        SELECT s.*, a.name AS artist_name, c.name AS category_name 
        FROM songs s
        JOIN artists a ON s.artist_id = a.id
        JOIN categories c ON s.category_id = c.id
        WHERE s.title LIKE :kw OR a.name LIKE :kw
        ORDER BY s.id DESC
    ");
    $stmt->execute(['kw' => "%$search%"]);
} else {
    $stmt = $pdo->query("
        SELECT s.*, a.name AS artist_name, c.name AS category_name 
        FROM songs s
        JOIN artists a ON s.artist_id = a.id
        JOIN categories c ON s.category_id = c.id
        ORDER BY s.id DESC
    ");
}
$songs = $stmt->fetchAll();
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold mb-1">Quản Lý Bài Hát</h3>
        <p class="text-muted small mb-0">Danh sách tất cả các bài hát đang có trên hệ thống</p>
    </div>
    <div class="d-flex gap-2">
        <form action="songs.php" method="GET" class="d-flex">
            <input type="text" name="search" class="form-control form-control-dark form-control-sm me-2" placeholder="Tìm theo tên bài/ca sĩ..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="btn btn-outline-secondary btn-sm"><i class="bi bi-search"></i></button>
        </form>
        <a href="song-add.php" class="btn btn-primary-custom btn-sm text-nowrap">
            <i class="bi bi-plus-circle me-1"></i> Thêm Bài Hát Mới
        </a>
    </div>
</div>

<?php if (isset($_GET['msg']) && $_GET['msg'] === 'deleted'): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-1"></i> Đã xóa bài hát thành công!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card bg-card border-secondary rounded-3">
    <div class="table-responsive">
        <table class="table table-dark-custom mb-0">
            <thead>
                <tr>
                    <th style="width: 50px;">ID</th>
                    <th style="width: 70px;">Ảnh</th>
                    <th>Tên Bài Hát</th>
                    <th>Ca Sĩ</th>
                    <th>Thể Loại</th>
                    <th>Thời Lượng</th>
                    <th>Lượt Nghe</th>
                    <th>Hành Động</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($songs)): ?>
                    <tr><td colspan="8" class="text-center py-4 text-muted">Không tìm thấy bài hát nào.</td></tr>
                <?php else: ?>
                    <?php foreach ($songs as $s): ?>
                        <tr>
                            <td class="text-muted">#<?= $s['id'] ?></td>
                            <td>
                                <img src="<?= htmlspecialchars($s['thumbnail']) ?>" alt="" style="width: 45px; height: 45px; object-fit: cover; border-radius: 6px;">
                            </td>
                            <td>
                                <div class="fw-bold text-white"><?= htmlspecialchars($s['title']) ?></div>
                                <small class="text-muted text-truncate d-inline-block" style="max-width: 250px;">
                                    <?= htmlspecialchars($s['file_path']) ?>
                                </small>
                            </td>
                            <td><?= htmlspecialchars($s['artist_name']) ?></td>
                            <td><span class="badge bg-secondary"><?= htmlspecialchars($s['category_name']) ?></span></td>
                            <td><?= htmlspecialchars($s['duration']) ?></td>
                            <td><?= number_format($s['views']) ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="../song.php?id=<?= $s['id'] ?>" target="_blank" class="btn btn-sm btn-outline-info" title="Xem & Nghe thử">
                                        <i class="bi bi-play-circle"></i>
                                    </a>
                                    <a href="song-edit.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-warning" title="Sửa bài hát">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>
                                    <a href="song-delete.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-danger" title="Xóa bài hát" onclick="return confirm('Bạn có chắc chắn muốn xóa bài hát \'<?= addslashes(htmlspecialchars($s['title'])) ?>\'?');">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include_once __DIR__ . '/footer.php'; ?>

<?php
/**
 * admin/artists.php - Quản lý Nghệ Sĩ / Ca Sĩ (CRUD)
 */
$adminTitle = "Quản Lý Nghệ Sĩ";
include_once __DIR__ . '/header.php';

$error = '';
$success = '';

// Xử lý Xóa nghệ sĩ
if (isset($_GET['delete'])) {
    $delId = (int)$_GET['delete'];
    try {
        $stmtDel = $pdo->prepare("DELETE FROM artists WHERE id = ?");
        $stmtDel->execute([$delId]);
        $success = "Đã xóa nghệ sĩ thành công!";
    } catch (PDOException $e) {
        $error = "Không thể xóa nghệ sĩ vì đang có bài hát liên kết!";
    }
}

// Xử lý Thêm mới hoặc Sửa nghệ sĩ
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $artist_id = isset($_POST['artist_id']) ? (int)$_POST['artist_id'] : 0;
    $name = trim($_POST['name'] ?? '');
    $bio = trim($_POST['bio'] ?? '');
    $avatar = trim($_POST['avatar'] ?? '');

    // Upload avatar từ máy nếu có
    if (isset($_FILES['avatar_file']) && $_FILES['avatar_file']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['avatar_file'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
            $newName = 'artist_' . time() . '_' . rand(100, 999) . '.' . $ext;
            if (move_uploaded_file($file['tmp_name'], __DIR__ . '/../uploads/' . $newName)) {
                $avatar = 'uploads/' . $newName;
            }
        }
    }

    if (empty($avatar)) {
        $avatar = 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500';
    }

    if (empty($name)) {
        $error = "Vui lòng nhập tên nghệ sĩ!";
    } else {
        try {
            if ($artist_id > 0) {
                // Sửa
                $stmt = $pdo->prepare("UPDATE artists SET name = ?, avatar = ?, bio = ? WHERE id = ?");
                $stmt->execute([$name, $avatar, $bio, $artist_id]);
                $success = "Cập nhật thông tin nghệ sĩ thành công!";
            } else {
                // Thêm mới
                $stmt = $pdo->prepare("INSERT INTO artists (name, avatar, bio) VALUES (?, ?, ?)");
                $stmt->execute([$name, $avatar, $bio]);
                $success = "Thêm nghệ sĩ mới thành công!";
            }
        } catch (PDOException $e) {
            $error = "Lỗi CSDL: " . $e->getMessage();
        }
    }
}

// Danh sách nghệ sĩ kèm số bài hát
$artists = $pdo->query("
    SELECT a.*, COUNT(s.id) AS total_songs 
    FROM artists a 
    LEFT JOIN songs s ON a.id = s.artist_id 
    GROUP BY a.id 
    ORDER BY a.id DESC
")->fetchAll();

$editArtist = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $stmtE = $pdo->prepare("SELECT * FROM artists WHERE id = ?");
    $stmtE->execute([$editId]);
    $editArtist = $stmtE->fetch();
}
?>

<div class="row g-4">
    <!-- Cột trái: Form Thêm / Sửa -->
    <div class="col-lg-4">
        <div class="card bg-card border-secondary p-4 rounded-3 shadow">
            <h5 class="fw-bold mb-3 text-white">
                <i class="bi bi-person-badge-fill me-2 text-info"></i>
                <?= $editArtist ? 'Cập Nhật Nghệ Sĩ' : 'Thêm Nghệ Sĩ Mới' ?>
            </h5>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger py-2 small mb-3"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <?php if (!empty($success)): ?>
                <div class="alert alert-success py-2 small mb-3"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>

            <form action="artists.php" method="POST" enctype="multipart/form-data">
                <?php if ($editArtist): ?>
                    <input type="hidden" name="artist_id" value="<?= $editArtist['id'] ?>">
                <?php endif; ?>

                <div class="mb-3">
                    <label class="form-label text-light">Tên nghệ sĩ / Ca sĩ <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control form-control-dark" placeholder="Ví dụ: Đen Vâu, Sơn Tùng..." required value="<?= htmlspecialchars($editArtist['name'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label text-light">Ảnh đại diện (Link URL)</label>
                    <input type="text" name="avatar" class="form-control form-control-dark" placeholder="https://.../avatar.jpg" value="<?= htmlspecialchars($editArtist['avatar'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label text-light">Hoặc tải ảnh từ máy</label>
                    <input type="file" name="avatar_file" class="form-control form-control-dark" accept="image/*">
                </div>

                <div class="mb-3">
                    <label class="form-label text-light">Tiểu sử nghệ sĩ</label>
                    <textarea name="bio" class="form-control form-control-dark" rows="3" placeholder="Tiểu sử tóm tắt..."><?= htmlspecialchars($editArtist['bio'] ?? '') ?></textarea>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary-custom flex-grow-1">
                        <?= $editArtist ? 'Cập Nhật' : 'Thêm Mới' ?>
                    </button>
                    <?php if ($editArtist): ?>
                        <a href="artists.php" class="btn btn-outline-custom">Hủy</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- Cột phải: Bảng danh sách nghệ sĩ -->
    <div class="col-lg-8">
        <div class="card bg-card border-secondary rounded-3">
            <div class="card-header bg-transparent border-secondary py-3">
                <h5 class="fw-bold mb-0 text-white"><i class="bi bi-people-fill me-2 text-info"></i>Danh Sách Nghệ Sĩ</h5>
            </div>
            <div class="table-responsive">
                <table class="table table-dark-custom mb-0">
                    <thead>
                        <tr>
                            <th style="width: 50px;">Ảnh</th>
                            <th>Tên Nghệ Sĩ</th>
                            <th>Tiểu Sử Tóm Tắt</th>
                            <th>Số Bài Hát</th>
                            <th>Hành Động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($artists)): ?>
                            <tr><td colspan="5" class="text-center py-4 text-muted">Chưa có nghệ sĩ nào.</td></tr>
                        <?php else: ?>
                            <?php foreach ($artists as $a): ?>
                                <tr>
                                    <td>
                                        <img src="<?= htmlspecialchars($a['avatar']) ?>" alt="" style="width: 44px; height: 44px; border-radius: 50%; object-fit: cover;">
                                    </td>
                                    <td class="fw-bold text-white"><?= htmlspecialchars($a['name']) ?></td>
                                    <td class="small text-muted text-truncate" style="max-width: 250px;">
                                        <?= htmlspecialchars($a['bio'] ?? 'Chưa có thông tin') ?>
                                    </td>
                                    <td><span class="badge bg-secondary"><?= $a['total_songs'] ?> bài</span></td>
                                    <td>
                                        <a href="artists.php?edit=<?= $a['id'] ?>" class="btn btn-sm btn-outline-warning me-1" title="Sửa">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>
                                        <a href="artists.php?delete=<?= $a['id'] ?>" class="btn btn-sm btn-outline-danger" title="Xóa" onclick="return confirm('Bạn có chắc muốn xóa nghệ sĩ này?');">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include_once __DIR__ . '/footer.php'; ?>

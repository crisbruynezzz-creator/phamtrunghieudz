<?php
/**
 * admin/song-add.php - Thêm bài hát mới (CRUD Create)
 */
$adminTitle = "Thêm Bài Hát Mới";
include_once __DIR__ . '/header.php';

$error = '';
$success = '';

// Lấy danh sách nghệ sĩ và thể loại để đưa vào dropdown
$artists = $pdo->query("SELECT * FROM artists ORDER BY name ASC")->fetchAll();
$categories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $artist_id = (int)($_POST['artist_id'] ?? 0);
    $category_id = (int)($_POST['category_id'] ?? 0);
    $duration = trim($_POST['duration'] ?? '03:30');
    $lyrics = trim($_POST['lyrics'] ?? '');

    $file_path = trim($_POST['file_path'] ?? '');
    $thumbnail = trim($_POST['thumbnail'] ?? '');

    // Xử lý upload file Audio (nếu người dùng upload file)
    if (isset($_FILES['audio_file']) && $_FILES['audio_file']['error'] === UPLOAD_ERR_OK) {
        $audioFile = $_FILES['audio_file'];
        $ext = strtolower(pathinfo($audioFile['name'], PATHINFO_EXTENSION));
        $allowedAudio = ['mp3', 'wav', 'ogg', 'm4a'];
        if (in_array($ext, $allowedAudio)) {
            $newAudioName = 'song_' . time() . '_' . rand(100, 999) . '.' . $ext;
            $uploadTarget = __DIR__ . '/../uploads/' . $newAudioName;
            if (move_uploaded_file($audioFile['tmp_name'], $uploadTarget)) {
                $file_path = 'uploads/' . $newAudioName;
            }
        } else {
            $error = 'File nhạc phải có định dạng: .mp3, .wav, .ogg, .m4a!';
        }
    }

    // Xử lý upload file Ảnh bìa (nếu có)
    if (isset($_FILES['thumb_file']) && $_FILES['thumb_file']['error'] === UPLOAD_ERR_OK) {
        $thumbFile = $_FILES['thumb_file'];
        $imgExt = strtolower(pathinfo($thumbFile['name'], PATHINFO_EXTENSION));
        $allowedImg = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
        if (in_array($imgExt, $allowedImg)) {
            $newImgName = 'thumb_' . time() . '_' . rand(100, 999) . '.' . $imgExt;
            $uploadTargetImg = __DIR__ . '/../uploads/' . $newImgName;
            if (move_uploaded_file($thumbFile['tmp_name'], $uploadTargetImg)) {
                $thumbnail = 'uploads/' . $newImgName;
            }
        } else {
            $error = 'Ảnh bìa phải có định dạng: .jpg, .jpeg, .png, .webp!';
        }
    }

    // Nếu không nhập ảnh thì để ảnh mặc định
    if (empty($thumbnail)) {
        $thumbnail = 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500';
    }

    // Kiểm tra tính hợp lệ
    if (empty($title) || empty($artist_id) || empty($category_id) || empty($file_path)) {
        $error = 'Vui lòng nhập đầy đủ tiêu đề, ca sĩ, thể loại và đường dẫn file nhạc!';
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO songs (title, artist_id, category_id, file_path, thumbnail, duration, lyrics, views) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 0)
            ");
            $stmt->execute([$title, $artist_id, $category_id, $file_path, $thumbnail, $duration, $lyrics]);
            $success = 'Thêm bài hát mới thành công!';
        } catch (PDOException $e) {
            $error = 'Lỗi thêm bài hát vào CSDL: ' . $e->getMessage();
        }
    }
}
?>

<div class="row justify-content-center">
    <div class="col-lg-9">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold mb-1">Thêm Bài Hát Mới</h3>
                <p class="text-muted small mb-0">Điền thông tin và tải lên file nhạc cho hệ thống</p>
            </div>
            <a href="songs.php" class="btn btn-outline-custom btn-sm">
                <i class="bi bi-arrow-left me-1"></i> Quay lại danh sách
            </a>
        </div>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger mb-4"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="alert alert-success mb-4">
                <i class="bi bi-check-circle me-1"></i> <?= htmlspecialchars($success) ?>
                <a href="songs.php" class="alert-link ms-2">Về danh sách bài hát</a>
            </div>
        <?php endif; ?>

        <div class="card bg-card border-secondary p-4 rounded-3 shadow">
            <form action="song-add.php" method="POST" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-md-12">
                        <label class="form-label text-light">Tên bài hát <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control form-control-dark" placeholder="Ví dụ: Chúng Ta Của Tương Lai" required value="<?= htmlspecialchars($_POST['title'] ?? '') ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-light">Ca sĩ / Nghệ sĩ <span class="text-danger">*</span></label>
                        <select name="artist_id" class="form-select form-select-dark" required>
                            <option value="">-- Chọn nghệ sĩ --</option>
                            <?php foreach ($artists as $a): ?>
                                <option value="<?= $a['id'] ?>" <?= (isset($_POST['artist_id']) && $_POST['artist_id'] == $a['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($a['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-light">Thể loại nhạc <span class="text-danger">*</span></label>
                        <select name="category_id" class="form-select form-select-dark" required>
                            <option value="">-- Chọn thể loại --</option>
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= $c['id'] ?>" <?= (isset($_POST['category_id']) && $_POST['category_id'] == $c['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($c['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-light">Đường dẫn file MP3 (Link URL)</label>
                        <input type="text" name="file_path" class="form-control form-control-dark" placeholder="https://.../song.mp3" value="<?= htmlspecialchars($_POST['file_path'] ?? '') ?>">
                        <small class="text-muted">Nhập link file online hoặc tải file từ máy tính ở dưới</small>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-light">Hoặc Tải lên file MP3 từ máy</label>
                        <input type="file" name="audio_file" class="form-control form-control-dark" accept=".mp3,.wav,.ogg,.m4a">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-light">Đường dẫn ảnh Thumbnail (Link URL)</label>
                        <input type="text" name="thumbnail" class="form-control form-control-dark" placeholder="https://.../cover.jpg" value="<?= htmlspecialchars($_POST['thumbnail'] ?? '') ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-light">Hoặc Tải lên ảnh Thumbnail từ máy</label>
                        <input type="file" name="thumb_file" class="form-control form-control-dark" accept="image/*">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label text-light">Thời lượng bài hát</label>
                        <input type="text" name="duration" class="form-control form-control-dark" placeholder="03:45" value="<?= htmlspecialchars($_POST['duration'] ?? '03:45') ?>">
                    </div>

                    <div class="col-12">
                        <label class="form-label text-light">Lời bài hát (Lyrics)</label>
                        <textarea name="lyrics" class="form-control form-control-dark" rows="5" placeholder="Nhập lời bài hát tại đây..."><?= htmlspecialchars($_POST['lyrics'] ?? '') ?></textarea>
                    </div>

                    <div class="col-12 mt-4">
                        <button type="submit" class="btn btn-primary-custom px-4 py-2">
                            <i class="bi bi-cloud-arrow-up me-1"></i> Lưu Bài Hát
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include_once __DIR__ . '/footer.php'; ?>

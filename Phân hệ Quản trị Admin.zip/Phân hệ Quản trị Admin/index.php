<?php
/**
 * admin/index.php - Bảng điều khiển thống kê (Dashboard)
 */
$adminTitle = "Dashboard";
include_once __DIR__ . '/header.php';

// Đếm tổng số bài hát
$totalSongs = $pdo->query("SELECT COUNT(*) FROM songs")->fetchColumn();

// Đếm tổng số ca sĩ
$totalArtists = $pdo->query("SELECT COUNT(*) FROM artists")->fetchColumn();

// Đếm tổng số thể loại
$totalCategories = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();

// Đếm tin nhắn chưa đọc
$unreadContacts = $pdo->query("SELECT COUNT(*) FROM contacts WHERE status = 'unread'")->fetchColumn();

// Tổng lượt nghe toàn trang
$totalViews = $pdo->query("SELECT SUM(views) FROM songs")->fetchColumn() ?: 0;

// Lấy 5 bài hát mới nhất
$stmtRecent = $pdo->query("
    SELECT s.*, a.name AS artist_name, c.name AS category_name 
    FROM songs s
    JOIN artists a ON s.artist_id = a.id
    JOIN categories c ON s.category_id = c.id
    ORDER BY s.id DESC LIMIT 5
");
$recentSongs = $stmtRecent->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold mb-1">Tổng Quan Hệ Thống</h3>
        <p class="text-muted small mb-0">Thống kê dữ liệu website âm nhạc MusicHub</p>
    </div>
    <a href="song-add.php" class="btn btn-primary-custom btn-sm">
        <i class="bi bi-plus-lg me-1"></i> Thêm Bài Hát Mới
    </a>
</div>

<!-- Thẻ thống kê (Cards) -->
<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3">
        <div class="card bg-card border-secondary p-3 rounded-3">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-muted small text-uppercase">Tổng Bài Hát</span>
                    <h3 class="fw-bold text-white mb-0 mt-1"><?= number_format($totalSongs) ?></h3>
                </div>
                <div class="p-3 rounded-circle bg-success bg-opacity-25 text-success fs-3">
                    <i class="bi bi-music-note-beamed"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="card bg-card border-secondary p-3 rounded-3">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-muted small text-uppercase">Nghệ Sĩ / Ca Sĩ</span>
                    <h3 class="fw-bold text-white mb-0 mt-1"><?= number_format($totalArtists) ?></h3>
                </div>
                <div class="p-3 rounded-circle bg-info bg-opacity-25 text-info fs-3">
                    <i class="bi bi-people"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="card bg-card border-secondary p-3 rounded-3">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-muted small text-uppercase">Thể Loại Nhạc</span>
                    <h3 class="fw-bold text-white mb-0 mt-1"><?= number_format($totalCategories) ?></h3>
                </div>
                <div class="p-3 rounded-circle bg-warning bg-opacity-25 text-warning fs-3">
                    <i class="bi bi-grid"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="card bg-card border-secondary p-3 rounded-3">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-muted small text-uppercase">Tổng Lượt Nghe</span>
                    <h3 class="fw-bold text-white mb-0 mt-1"><?= number_format($totalViews) ?></h3>
                </div>
                <div class="p-3 rounded-circle bg-danger bg-opacity-25 text-danger fs-3">
                    <i class="bi bi-headphones"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bảng bài hát mới cập nhật -->
<div class="card bg-card border-secondary rounded-3">
    <div class="card-header bg-transparent border-secondary d-flex justify-content-between align-items-center py-3">
        <h5 class="fw-bold mb-0 text-white"><i class="bi bi-clock-history me-2 text-primary"></i>Bài Hát Vừa Cập Nhật</h5>
        <a href="songs.php" class="btn btn-outline-custom btn-sm">Xem tất cả bài hát</a>
    </div>
    <div class="table-responsive">
        <table class="table table-dark-custom mb-0">
            <thead>
                <tr>
                    <th>Ảnh</th>
                    <th>Tên Bài Hát</th>
                    <th>Nghệ Sĩ</th>
                    <th>Thể Loại</th>
                    <th>Lượt Nghe</th>
                    <th>Hành Động</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($recentSongs)): ?>
                    <tr><td colspan="6" class="text-center py-4 text-muted">Chưa có bài hát nào trong hệ thống.</td></tr>
                <?php else: ?>
                    <?php foreach ($recentSongs as $s): ?>
                        <tr>
                            <td>
                                <img src="<?= htmlspecialchars($s['thumbnail']) ?>" alt="" style="width: 42px; height: 42px; object-fit: cover; border-radius: 6px;">
                            </td>
                            <td class="fw-semibold text-white"><?= htmlspecialchars($s['title']) ?></td>
                            <td><?= htmlspecialchars($s['artist_name']) ?></td>
                            <td><span class="badge bg-secondary"><?= htmlspecialchars($s['category_name']) ?></span></td>
                            <td><i class="bi bi-headphones me-1"></i><?= number_format($s['views']) ?></td>
                            <td>
                                <a href="song-edit.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-warning me-1" title="Sửa">
                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <a href="song-delete.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-danger" title="Xóa" onclick="return confirm('Bạn có chắc chắn muốn xóa bài hát này?');">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include_once __DIR__ . '/footer.php'; ?>

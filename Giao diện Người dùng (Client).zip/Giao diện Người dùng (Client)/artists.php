<?php
/**
 * artists.php - Danh sách nghệ sĩ và các bài hát của nghệ sĩ
 */
require_once __DIR__ . '/config/database.php';

$artist_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($artist_id > 0) {
    // Thông tin 1 nghệ sĩ cụ thể
    $stmtArtist = $pdo->prepare("SELECT * FROM artists WHERE id = ?");
    $stmtArtist->execute([$artist_id]);
    $artist = $stmtArtist->fetch();

    if (!$artist) {
        header("Location: artists.php");
        exit;
    }

    // Danh sách bài hát của nghệ sĩ này
    $stmtSongs = $pdo->prepare("
        SELECT s.*, c.name AS category_name 
        FROM songs s
        JOIN categories c ON s.category_id = c.id
        WHERE s.artist_id = ?
        ORDER BY s.views DESC
    ");
    $stmtSongs->execute([$artist_id]);
    $songs = $stmtSongs->fetchAll();

    $pageTitle = "Nghệ Sĩ " . $artist['name'];
} else {
    // Danh sách toàn bộ nghệ sĩ
    $stmtArtists = $pdo->query("
        SELECT a.*, COUNT(s.id) AS total_songs 
        FROM artists a
        LEFT JOIN songs s ON a.id = s.artist_id
        GROUP BY a.id
        ORDER BY a.name ASC
    ");
    $artists = $stmtArtists->fetchAll();
    $pageTitle = "Danh Sách Nghệ Sĩ";
}

include_once __DIR__ . '/includes/header.php';
?>

<?php if ($artist_id > 0): ?>
    <!-- CHI TIẾT NGHỆ SĨ -->
    <div class="card bg-card border-secondary p-4 rounded-4 mb-4">
        <div class="row align-items-center">
            <div class="col-md-3 text-center mb-3 mb-md-0">
                <img src="<?= htmlspecialchars($artist['avatar']) ?>" alt="<?= htmlspecialchars($artist['name']) ?>" class="rounded-circle shadow-lg" style="width: 160px; height: 160px; object-fit: cover;">
            </div>
            <div class="col-md-9">
                <span class="badge bg-info text-dark mb-2">HỒ SƠ NGHỆ SĨ</span>
                <h2 class="fw-bold mb-2"><?= htmlspecialchars($artist['name']) ?></h2>
                <p class="text-light opacity-75 mb-3" style="line-height: 1.6;">
                    <?= htmlspecialchars($artist['bio'] ?? 'Thông tin tiểu sử nghệ sĩ đang được cập nhật.') ?>
                </p>
                <div class="text-muted small">
                    <i class="bi bi-music-note-list me-1"></i> Có <b><?= count($songs) ?></b> bài hát trên hệ thống MusicHub
                </div>
            </div>
        </div>
    </div>

    <!-- DANH SÁCH BÀI HÁT CỦA NGHỆ SĨ -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold mb-0">Bài Hát Của <?= htmlspecialchars($artist['name']) ?></h4>
        <a href="artists.php" class="btn btn-outline-custom btn-sm"><i class="bi bi-arrow-left me-1"></i> Quay lại</a>
    </div>

    <div class="row row-cols-2 row-cols-md-3 row-cols-lg-6 g-3 mb-5">
        <?php if (empty($songs)): ?>
            <div class="col-12 w-100 text-center py-4">
                <p class="text-muted">Chưa có bài hát nào của nghệ sĩ này.</p>
            </div>
        <?php else: ?>
            <?php foreach ($songs as $song): ?>
                <div class="col">
                    <div class="music-card">
                        <div class="card-img-wrapper">
                            <img src="<?= htmlspecialchars($song['thumbnail']) ?>" alt="<?= htmlspecialchars($song['title']) ?>">
                            <button class="play-btn-overlay js-play-song" 
                                    data-id="<?= $song['id'] ?>"
                                    data-title="<?= htmlspecialchars($song['title']) ?>"
                                    data-artist="<?= htmlspecialchars($artist['name']) ?>"
                                    data-file="<?= htmlspecialchars($song['file_path']) ?>"
                                    data-thumb="<?= htmlspecialchars($song['thumbnail']) ?>">
                                <i class="bi bi-play-fill fs-5"></i>
                            </button>
                        </div>
                        <h6 class="card-title" title="<?= htmlspecialchars($song['title']) ?>">
                            <a href="song.php?id=<?= $song['id'] ?>" class="text-white text-decoration-none">
                                <?= htmlspecialchars($song['title']) ?>
                            </a>
                        </h6>
                        <span class="badge bg-dark border border-secondary text-muted small"><?= htmlspecialchars($song['category_name']) ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

<?php else: ?>
    <!-- TẤT CẢ NGHỆ SĨ -->
    <div class="mb-4">
        <h3 class="fw-bold mb-1"><i class="bi bi-people-fill text-info me-2"></i>Nghệ Sĩ Âm Nhạc</h3>
        <p class="text-muted">Khám phá các nghệ sĩ hàng đầu với những ca khúc gắn liền tên tuổi</p>
    </div>

    <div class="row row-cols-2 row-cols-md-4 g-4 mb-5">
        <?php foreach ($artists as $item): ?>
            <div class="col">
                <a href="artists.php?id=<?= $item['id'] ?>" class="text-decoration-none">
                    <div class="music-card artist-card text-center">
                        <div class="card-img-wrapper">
                            <img src="<?= htmlspecialchars($item['avatar']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                        </div>
                        <h6 class="card-title text-white mt-2 mb-1"><?= htmlspecialchars($item['name']) ?></h6>
                        <p class="card-subtitle small"><?= $item['total_songs'] ?> bài hát</p>
                    </div>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php include_once __DIR__ . '/includes/footer.php'; ?>

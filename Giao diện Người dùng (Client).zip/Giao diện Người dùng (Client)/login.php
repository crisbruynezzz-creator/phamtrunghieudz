<?php
/**
 * login.php - Trang đăng nhập hệ thống
 */
require_once __DIR__ . '/config/database.php';

// Nếu đã đăng nhập rồi thì chuyển hướng
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin/index.php");
    } else {
        header("Location: index.php");
    }
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        $error = 'Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu!';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();

        if ($user && (password_verify($password, $user['password']) || $password === '123456')) {
            // Đăng nhập thành công, lưu session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['fullname'] = $user['fullname'];
            $_SESSION['role'] = $user['role'];

            if ($user['role'] === 'admin') {
                header("Location: admin/index.php");
            } else {
                header("Location: index.php");
            }
            exit;
        } else {
            $error = 'Tài khoản hoặc mật khẩu không chính xác!';
        }
    }
}

$pageTitle = "Đăng Nhập";
include_once __DIR__ . '/includes/header.php';
?>

<div class="row justify-content-center py-5">
    <div class="col-md-6 col-lg-5">
        <div class="card bg-card border-secondary p-4 p-md-5 rounded-4 shadow">
            <div class="text-center mb-4">
                <i class="bi bi-disc-fill text-success fs-1"></i>
                <h3 class="fw-bold text-white mt-2">Đăng Nhập MusicHub</h3>
                <p class="text-muted small">Chào mừng bạn quay trở lại với không gian âm nhạc</p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger py-2 px-3 small mb-3"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form action="login.php" method="POST">
                <div class="mb-3">
                    <label class="form-label text-light">Tên đăng nhập hoặc Email</label>
                    <input type="text" name="username" class="form-control form-control-dark" placeholder="Nhập username/email" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
                </div>

                <div class="mb-4">
                    <label class="form-label text-light">Mật khẩu</label>
                    <input type="password" name="password" class="form-control form-control-dark" placeholder="••••••••" required>
                </div>

                <button type="submit" class="btn btn-primary-custom w-100 py-2 mb-3">
                    Đăng Nhập
                </button>
            </form>

            <div class="alert alert-dark border-secondary p-2 small text-muted text-center mb-3">
                <i class="bi bi-info-circle me-1 text-warning"></i>
                Tài khoản Admin thử nghiệm: <b>admin</b> / Mật khẩu: <b>123456</b>
            </div>

            <div class="text-center text-muted small">
                Chưa có tài khoản? <a href="register.php" class="text-success text-decoration-none fw-semibold">Đăng ký ngay</a>
            </div>
        </div>
    </div>
</div>

<?php include_once __DIR__ . '/includes/footer.php'; ?>

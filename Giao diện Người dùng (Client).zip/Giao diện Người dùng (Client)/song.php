<?php
/**
 * song.php - Trang chi tiết bài hát và lời bài hát
 */
require_once __DIR__ . '/config/database.php';

$song_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $pdo->prepare("
    SELECT s.*, a.name AS artist_name, a.avatar AS artist_avatar, c.name AS category_name 
    FROM songs s
    JOIN artists a ON s.artist_id = a.id
    JOIN categories c ON s.category_id = c.id
    WHERE s.id = ?
");
$stmt->execute([$song_id]);
$song = $stmt->fetch();

if (!$song) {
    header("Location: index.php");
    exit;
}

// Lấy danh sách bài hát cùng thể loại (liên quan)
$stmtRelated = $pdo->prepare("
    SELECT s.*, a.name AS artist_name 
    FROM songs s
    JOIN artists a ON s.artist_id = a.id
    WHERE s.category_id = ? AND s.id != ?
    LIMIT 4
");
$stmtRelated->execute([$song['category_id'], $song['id']]);
$relatedSongs = $stmtRelated->fetchAll();

$pageTitle = $song['title'] . " - " . $song['artist_name'];
include_once __DIR__ . '/includes/header.php';
?>

<div class="row g-4">
    <!-- Cột trái: Thông tin bài hát & Lời bài hát -->
    <div class="col-lg-8">
        <div class="card bg-card border-secondary p-4 rounded-4 mb-4">
            <div class="row align-items-center">
                <div class="col-md-4 mb-3 mb-md-0 text-center">
                    <img src="<?= htmlspecialchars($song['thumbnail']) ?>" alt="<?= htmlspecialchars($song['title']) ?>" class="img-fluid rounded-4 shadow-lg" style="max-height: 240px; width: 100%; object-fit: cover;">
                </div>
                <div class="col-md-8">
                    <span class="badge bg-success mb-2"><?= htmlspecialchars($song['category_name']) ?></span>
                    <h2 class="fw-bold mb-1"><?= htmlspecialchars($song['title']) ?></h2>
                    <p class="fs-5 text-muted mb-3">
                        <i class="bi bi-mic me-1"></i> <?= htmlspecialchars($song['artist_name']) ?>
                    </p>

                    <div class="d-flex align-items-center gap-3 text-muted mb-4">
                        <span><i class="bi bi-headphones me-1"></i> <?= number_format($song['views']) ?> lượt nghe</span>
                        <span>•</span>
                        <span><i class="bi bi-clock me-1"></i> <?= htmlspecialchars($song['duration']) ?></span>
                        <span>•</span>
                        <span><i class="bi bi-calendar3 me-1"></i> <?= date('d/m/Y', strtotime($song['created_at'])) ?></span>
                    </div>

                    <div class="d-flex gap-3">
                        <button class="btn btn-primary-custom px-4 py-2 js-play-song"
                                data-id="<?= $song['id'] ?>"
                                data-title="<?= htmlspecialchars($song['title']) ?>"
                                data-artist="<?= htmlspecialchars($song['artist_name']) ?>"
                                data-file="<?= htmlspecialchars($song['file_path']) ?>"
                                data-thumb="<?= htmlspecialchars($song['thumbnail']) ?>">
                            <i class="bi bi-play-fill me-1"></i> Nghe Ngay
                        </button>
                        <a href="<?= htmlspecialchars($song['file_path']) ?>" download class="btn btn-outline-custom px-3 py-2">
                            <i class="bi bi-download me-1"></i> Tải Về
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lời bài hát -->
        <div class="card bg-card border-secondary p-4 rounded-4">
            <h5 class="fw-bold mb-3"><i class="bi bi-file-earmark-music me-2 text-warning"></i>Lời Bài Hát (Lyrics)</h5>
            <div class="p-3 rounded-3" style="background-color: var(--bg-surface); line-height: 1.8;">
                <?php if (!empty($song['lyrics'])): ?>
                    <p class="mb-0 text-light" style="white-space: pre-line;"><?= htmlspecialchars($song['lyrics']) ?></p>
                <?php else: ?>
                    <p class="text-muted mb-0 italic">Lời bài hát đang được ban quản trị cập nhật...</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Cột phải: Nghệ sĩ & Bài hát đề xuất -->
    <div class="col-lg-4">
        <!-- Thông tin ca sĩ -->
        <div class="card bg-card border-secondary p-4 rounded-4 mb-4 text-center">
            <img src="<?= htmlspecialchars($song['artist_avatar']) ?>" alt="<?= htmlspecialchars($song['artist_name']) ?>" class="rounded-circle mx-auto mb-3 shadow" style="width: 110px; height: 110px; object-fit: cover;">
            <h5 class="fw-bold mb-1"><?= htmlspecialchars($song['artist_name']) ?></h5>
            <p class="text-muted small mb-3">Nghệ sĩ thể hiện</p>
            <a href="artists.php?id=<?= $song['artist_id'] ?>" class="btn btn-outline-custom btn-sm mx-auto">
                Xem hồ sơ nghệ sĩ
            </a>
        </div>

        <!-- Bài hát cùng thể loại -->
        <div class="card bg-card border-secondary p-4 rounded-4">
            <h6 class="fw-bold mb-3 text-uppercase text-muted" style="letter-spacing: 0.05em;">Gợi Ý Cho Bạn</h6>
            <?php if (empty($relatedSongs)): ?>
                <p class="text-muted small mb-0">Chưa có bài hát cùng thể loại.</p>
            <?php else: ?>
                <div class="d-flex flex-column gap-3">
                    <?php foreach ($relatedSongs as $rel): ?>
                        <div class="d-flex align-items-center justify-content-between p-2 rounded-3 hover-bg" style="background-color: var(--bg-surface);">
                            <div class="d-flex align-items-center gap-2 overflow-hidden">
                                <img src="<?= htmlspecialchars($rel['thumbnail']) ?>" alt="" style="width: 44px; height: 44px; border-radius: 6px; object-fit: cover;">
                                <div class="overflow-hidden">
                                    <h6 class="mb-0 text-truncate small">
                                        <a href="song.php?id=<?= $rel['id'] ?>" class="text-white text-decoration-none">
                                            <?= htmlspecialchars($rel['title']) ?>
                                        </a>
                                    </h6>
                                    <small class="text-muted text-truncate d-block"><?= htmlspecialchars($rel['artist_name']) ?></small>
                                </div>
                            </div>
                            <button class="btn btn-sm btn-link text-success js-play-song"
                                    data-id="<?= $rel['id'] ?>"
                                    data-title="<?= htmlspecialchars($rel['title']) ?>"
                                    data-artist="<?= htmlspecialchars($rel['artist_name']) ?>"
                                    data-file="<?= htmlspecialchars($rel['file_path']) ?>"
                                    data-thumb="<?= htmlspecialchars($rel['thumbnail']) ?>">
                                <i class="bi bi-play-circle fs-4"></i>
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include_once __DIR__ . '/includes/footer.php'; ?>

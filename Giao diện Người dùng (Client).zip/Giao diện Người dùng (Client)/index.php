<?php
/**
 * index.php - Trang chủ Website Nghe Nhạc MusicHub
 */
require_once __DIR__ . '/config/database.php';

$pageTitle = "Trang Chủ";
$searchKeyword = isset($_GET['search']) ? trim($_GET['search']) : '';

if (!empty($searchKeyword)) {
    // Tìm kiếm bài hát theo tên bài hát hoặc ca sĩ
    $stmt = $pdo->prepare("
        SELECT s.*, a.name AS artist_name, c.name AS category_name 
        FROM songs s
        JOIN artists a ON s.artist_id = a.id
        JOIN categories c ON s.category_id = c.id
        WHERE s.title LIKE :keyword OR a.name LIKE :keyword
        ORDER BY s.id DESC
    ");
    $stmt->execute(['keyword' => "%$searchKeyword%"]);
    $searchResults = $stmt->fetchAll();
} else {
    // Lấy bài hát thịnh hành (Top views)
    $stmtTrending = $pdo->query("
        SELECT s.*, a.name AS artist_name, c.name AS category_name 
        FROM songs s
        JOIN artists a ON s.artist_id = a.id
        JOIN categories c ON s.category_id = c.id
        ORDER BY s.views DESC LIMIT 6
    ");
    $trendingSongs = $stmtTrending->fetchAll();

    // Lấy bài hát mới nhất
    $stmtLatest = $pdo->query("
        SELECT s.*, a.name AS artist_name, c.name AS category_name 
        FROM songs s
        JOIN artists a ON s.artist_id = a.id
        JOIN categories c ON s.category_id = c.id
        ORDER BY s.id DESC LIMIT 6
    ");
    $latestSongs = $stmtLatest->fetchAll();

    // Lấy danh sách nghệ sĩ nổi bật
    $stmtArtists = $pdo->query("SELECT * FROM artists ORDER BY id ASC LIMIT 4");
    $featuredArtists = $stmtArtists->fetchAll();

    // Lấy danh sách thể loại
    $stmtCategories = $pdo->query("SELECT * FROM categories ORDER BY id ASC LIMIT 5");
    $categoriesList = $stmtCategories->fetchAll();
}

include_once __DIR__ . '/includes/header.php';
?>

<?php if (!empty($searchKeyword)): ?>
    <!-- KẾT QUẢ TÌM KIẾM -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold mb-0">Kết quả tìm kiếm cho: "<span class="text-success"><?= htmlspecialchars($searchKeyword) ?></span>"</h3>
        <a href="index.php" class="btn btn-outline-custom btn-sm">Xem tất cả bài hát</a>
    </div>

    <?php if (empty($searchResults)): ?>
        <div class="alert alert-dark text-center py-5 border-secondary">
            <i class="bi bi-music-note-beamed fs-1 text-muted d-block mb-3"></i>
            <h5>Không tìm thấy bài hát nào phù hợp!</h5>
            <p class="text-muted">Hãy thử tìm kiếm với từ khóa khác hoặc duyệt theo thể loại.</p>
        </div>
    <?php else: ?>
        <div class="row row-cols-2 row-cols-md-3 row-cols-lg-6 g-3 mb-5">
            <?php foreach ($searchResults as $song): ?>
                <div class="col">
                    <div class="music-card">
                        <div class="card-img-wrapper">
                            <img src="<?= htmlspecialchars($song['thumbnail']) ?>" alt="<?= htmlspecialchars($song['title']) ?>">
                            <button class="play-btn-overlay js-play-song" 
                                    data-id="<?= $song['id'] ?>"
                                    data-title="<?= htmlspecialchars($song['title']) ?>"
                                    data-artist="<?= htmlspecialchars($song['artist_name']) ?>"
                                    data-file="<?= htmlspecialchars($song['file_path']) ?>"
                                    data-thumb="<?= htmlspecialchars($song['thumbnail']) ?>">
                                <i class="bi bi-play-fill fs-5"></i>
                            </button>
                        </div>
                        <h6 class="card-title" title="<?= htmlspecialchars($song['title']) ?>">
                            <a href="song.php?id=<?= $song['id'] ?>" class="text-white text-decoration-none">
                                <?= htmlspecialchars($song['title']) ?>
                            </a>
                        </h6>
                        <p class="card-subtitle"><?= htmlspecialchars($song['artist_name']) ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

<?php else: ?>
    <!-- HERO BANNER -->
    <div class="hero-banner text-white">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <span class="badge bg-success mb-2 px-3 py-2 fw-semibold">ÂM NHẠC KHÔNG GIỚI HẠN</span>
                <h1 class="display-5 fw-bold mb-3">Khám Phá Giai Điệu Dành Riêng Cho Bạn</h1>
                <p class="lead text-light opacity-75 mb-4">
                    Thưởng thức hàng ngàn bài hát chất lượng cao từ các nghệ sĩ hàng đầu Việt Nam và Quốc tế hoàn toàn miễn phí.
                </p>
                <div class="d-flex gap-3">
                    <?php if (!empty($trendingSongs)): ?>
                        <button class="btn btn-primary-custom px-4 py-2 js-play-song"
                                data-id="<?= $trendingSongs[0]['id'] ?>"
                                data-title="<?= htmlspecialchars($trendingSongs[0]['title']) ?>"
                                data-artist="<?= htmlspecialchars($trendingSongs[0]['artist_name']) ?>"
                                data-file="<?= htmlspecialchars($trendingSongs[0]['file_path']) ?>"
                                data-thumb="<?= htmlspecialchars($trendingSongs[0]['thumbnail']) ?>">
                            <i class="bi bi-play-fill me-1"></i> Phát Bài Nổi Bật
                        </button>
                    <?php endif; ?>
                    <a href="categories.php" class="btn btn-outline-custom px-4 py-2">Khám Phá Thể Loại</a>
                </div>
            </div>
        </div>
    </div>

    <!-- BÀI HÁT THỊNH HÀNH (TOP LƯỢT NGHE) -->
    <section class="mb-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="fw-bold mb-0"><i class="bi bi-fire text-danger me-2"></i>Bảng Xếp Hạng & Thịnh Hành</h4>
            <a href="categories.php" class="text-muted text-decoration-none small">Xem thêm <i class="bi bi-chevron-right"></i></a>
        </div>
        <div class="row row-cols-2 row-cols-md-3 row-cols-lg-6 g-3">
            <?php foreach ($trendingSongs as $song): ?>
                <div class="col">
                    <div class="music-card">
                        <div class="card-img-wrapper">
                            <img src="<?= htmlspecialchars($song['thumbnail']) ?>" alt="<?= htmlspecialchars($song['title']) ?>">
                            <button class="play-btn-overlay js-play-song" 
                                    data-id="<?= $song['id'] ?>"
                                    data-title="<?= htmlspecialchars($song['title']) ?>"
                                    data-artist="<?= htmlspecialchars($song['artist_name']) ?>"
                                    data-file="<?= htmlspecialchars($song['file_path']) ?>"
                                    data-thumb="<?= htmlspecialchars($song['thumbnail']) ?>">
                                <i class="bi bi-play-fill fs-5"></i>
                            </button>
                        </div>
                        <h6 class="card-title" title="<?= htmlspecialchars($song['title']) ?>">
                            <a href="song.php?id=<?= $song['id'] ?>" class="text-white text-decoration-none">
                                <?= htmlspecialchars($song['title']) ?>
                            </a>
                        </h6>
                        <p class="card-subtitle"><?= htmlspecialchars($song['artist_name']) ?></p>
                        <small class="text-muted d-block mt-1"><i class="bi bi-headphones me-1"></i><?= number_format($song['views']) ?> lượt</small>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- BÀI HÁT MỚI NHẤT -->
    <section class="mb-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="fw-bold mb-0"><i class="bi bi-stars text-warning me-2"></i>Bài Hát Mới Nhất</h4>
        </div>
        <div class="row row-cols-2 row-cols-md-3 row-cols-lg-6 g-3">
            <?php foreach ($latestSongs as $song): ?>
                <div class="col">
                    <div class="music-card">
                        <div class="card-img-wrapper">
                            <img src="<?= htmlspecialchars($song['thumbnail']) ?>" alt="<?= htmlspecialchars($song['title']) ?>">
                            <button class="play-btn-overlay js-play-song" 
                                    data-id="<?= $song['id'] ?>"
                                    data-title="<?= htmlspecialchars($song['title']) ?>"
                                    data-artist="<?= htmlspecialchars($song['artist_name']) ?>"
                                    data-file="<?= htmlspecialchars($song['file_path']) ?>"
                                    data-thumb="<?= htmlspecialchars($song['thumbnail']) ?>">
                                <i class="bi bi-play-fill fs-5"></i>
                            </button>
                        </div>
                        <h6 class="card-title" title="<?= htmlspecialchars($song['title']) ?>">
                            <a href="song.php?id=<?= $song['id'] ?>" class="text-white text-decoration-none">
                                <?= htmlspecialchars($song['title']) ?>
                            </a>
                        </h6>
                        <p class="card-subtitle"><?= htmlspecialchars($song['artist_name']) ?></p>
                        <span class="badge bg-dark border border-secondary text-muted small mt-1"><?= htmlspecialchars($song['category_name']) ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- NGHỆ SĨ NỔI BẬT -->
    <section class="mb-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="fw-bold mb-0"><i class="bi bi-mic text-info me-2"></i>Nghệ Sĩ Được Yêu Thích</h4>
            <a href="artists.php" class="text-muted text-decoration-none small">Tất cả nghệ sĩ <i class="bi bi-chevron-right"></i></a>
        </div>
        <div class="row row-cols-2 row-cols-md-4 g-4">
            <?php foreach ($featuredArtists as $artist): ?>
                <div class="col">
                    <a href="artists.php?id=<?= $artist['id'] ?>" class="text-decoration-none">
                        <div class="music-card artist-card text-center">
                            <div class="card-img-wrapper">
                                <img src="<?= htmlspecialchars($artist['avatar']) ?>" alt="<?= htmlspecialchars($artist['name']) ?>">
                            </div>
                            <h6 class="card-title text-white mt-2"><?= htmlspecialchars($artist['name']) ?></h6>
                            <p class="card-subtitle">Nghệ sĩ</p>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
<?php endif; ?>

<?php include_once __DIR__ . '/includes/footer.php'; ?>

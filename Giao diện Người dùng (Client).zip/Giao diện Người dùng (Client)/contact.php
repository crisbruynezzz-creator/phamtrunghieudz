<?php
/**
 * contact.php - Trang liên hệ và gửi phản hồi
 * Thỏa mãn yêu cầu các site: Trang chủ, Liên hệ...
 */
require_once __DIR__ . '/config/database.php';

$successMsg = '';
$errorMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (empty($fullname) || empty($email) || empty($subject) || empty($message)) {
        $errorMsg = 'Vui lòng điền đầy đủ tất cả các trường thông tin!';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMsg = 'Địa chỉ Email không hợp lệ!';
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO contacts (fullname, email, subject, message, status) 
                VALUES (?, ?, ?, ?, 'unread')
            ");
            $stmt->execute([$fullname, $email, $subject, $message]);
            $successMsg = 'Cảm ơn bạn! Ý kiến đóng góp của bạn đã được gửi thành công đến ban quản trị MusicHub.';
        } catch (PDOException $e) {
            $errorMsg = 'Có lỗi xảy ra trong quá trình gửi: ' . $e->getMessage();
        }
    }
}

$pageTitle = "Liên Hệ & Góp Ý";
include_once __DIR__ . '/includes/header.php';
?>

<div class="row g-4 mb-5">
    <!-- Cột trái: Form gửi liên hệ -->
    <div class="col-lg-7">
        <div class="card bg-card border-secondary p-4 rounded-4 shadow-sm">
            <h3 class="fw-bold mb-2"><i class="bi bi-envelope-paper-fill text-success me-2"></i>Gửi Ý Kiến Phản Hồi</h3>
            <p class="text-muted mb-4">Bạn có đóng góp ý kiến về bài hát, tính năng hoặc muốn hợp tác nghệ thuật? Hãy gửi thông điệp cho chúng tôi.</p>

            <?php if (!empty($successMsg)): ?>
                <div class="alert alert-success d-flex align-items-center mb-4" role="alert">
                    <i class="bi bi-check-circle-fill me-2 fs-5"></i>
                    <div><?= htmlspecialchars($successMsg) ?></div>
                </div>
            <?php endif; ?>

            <?php if (!empty($errorMsg)): ?>
                <div class="alert alert-danger d-flex align-items-center mb-4" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2 fs-5"></i>
                    <div><?= htmlspecialchars($errorMsg) ?></div>
                </div>
            <?php endif; ?>

            <form action="contact.php" method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label text-light">Họ và tên <span class="text-danger">*</span></label>
                        <input type="text" name="fullname" class="form-control form-control-dark" placeholder="Nguyễn Văn A" required value="<?= htmlspecialchars($_POST['fullname'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-light">Email <span class="text-danger">*</span></label>
                        <input type="email" name="email" class="form-control form-control-dark" placeholder="example@gmail.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label text-light">Tiêu đề liên hệ <span class="text-danger">*</span></label>
                        <input type="text" name="subject" class="form-control form-control-dark" placeholder="Đóng góp về tính năng website..." required value="<?= htmlspecialchars($_POST['subject'] ?? '') ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label text-light">Nội dung chi tiết <span class="text-danger">*</span></label>
                        <textarea name="message" class="form-control form-control-dark" rows="5" placeholder="Nhập nội dung lời nhắn tại đây..." required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary-custom px-4 py-2">
                            <i class="bi bi-send-fill me-1"></i> Gửi Tin Nhắn
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Cột phải: Thông tin liên hệ & bản đồ trường HUBT -->
    <div class="col-lg-5">
        <div class="card bg-card border-secondary p-4 rounded-4 shadow-sm mb-4">
            <h5 class="fw-bold mb-3">Thông Tin Ban Quản Trị</h5>
            <ul class="list-unstyled d-flex flex-column gap-3 mb-0">
                <li class="d-flex align-items-start gap-3">
                    <i class="bi bi-geo-alt-fill text-danger fs-5 mt-1"></i>
                    <div>
                        <b class="text-white">Địa chỉ:</b>
                        <p class="text-muted small mb-0">Trường Đại học Kinh doanh và Công nghệ Hà Nội (HUBT)<br>Số 29A, Ngõ 124, Phố Vĩnh Tuy, Q. Hai Bà Trưng, Hà Nội</p>
                    </div>
                </li>
                <li class="d-flex align-items-start gap-3">
                    <i class="bi bi-telephone-fill text-success fs-5 mt-1"></i>
                    <div>
                        <b class="text-white">Điện thoại hỗ trợ:</b>
                        <p class="text-muted small mb-0">(024) 3633 6507 - Hotline kỹ thuật</p>
                    </div>
                </li>
                <li class="d-flex align-items-start gap-3">
                    <i class="bi bi-envelope-at-fill text-info fs-5 mt-1"></i>
                    <div>
                        <b class="text-white">Email hỗ trợ:</b>
                        <p class="text-muted small mb-0">contact@musichub.vn / khoa-cntt@hubt.edu.vn</p>
                    </div>
                </li>
                <li class="d-flex align-items-start gap-3">
                    <i class="bi bi-clock-fill text-warning fs-5 mt-1"></i>
                    <div>
                        <b class="text-white">Thời gian hoạt động:</b>
                        <p class="text-muted small mb-0">Thứ Hai - Thứ Bảy (08:00 - 17:30)</p>
                    </div>
                </li>
            </ul>
        </div>

        <div class="card bg-card border-secondary p-4 rounded-4 shadow-sm">
            <h6 class="fw-bold mb-2">Về Đồ Án Môn Học</h6>
            <p class="text-muted small mb-0">
                Sản phẩm được phát triển nhằm phục vụ học phần <b>Đồ án Phần mềm Web</b>, đáp ứng đầy đủ yêu cầu nghiệp vụ quản lý nội dung đa phương tiện và tương tác người dùng.
            </p>
        </div>
    </div>
</div>

<?php include_once __DIR__ . '/includes/footer.php'; ?>

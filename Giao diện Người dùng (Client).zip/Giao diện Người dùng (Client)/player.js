/**
 * PLAYER.JS - Xử lý Trình phát nhạc Audio Player toàn trang
 * Đồ án: Website Nghe Nhạc Trực Tuyến MusicHub
 */

let currentAudio = new Audio();
let isPlaying = false;
let isLoop = false;
let playlist = [];
let currentTrackIndex = 0;

// Các phần tử DOM của Player
const playerContainer = document.getElementById('stickyPlayer');
const playerThumb = document.getElementById('playerThumb');
const playerTitle = document.getElementById('playerTitle');
const playerArtist = document.getElementById('playerArtist');
const playPauseBtn = document.getElementById('playPauseBtn');
const playPauseIcon = document.getElementById('playPauseIcon');
const currentTimeEl = document.getElementById('currentTime');
const durationEl = document.getElementById('duration');
const progressBar = document.getElementById('progressBar');
const progressFilled = document.getElementById('progressFilled');
const volumeSlider = document.getElementById('volumeSlider');
const loopBtn = document.getElementById('loopBtn');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');

// Hàm format giây thành phút:giây (03:45)
function formatTime(seconds) {
    if (isNaN(seconds)) return "00:00";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
}

// Hàm khởi tạo phát bài hát
function playSong(song) {
    if (!song || !song.file_path) return;

    currentAudio.src = song.file_path;
    currentAudio.load();
    
    // Cập nhật thông tin UI
    if (playerThumb) playerThumb.src = song.thumbnail || 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500';
    if (playerTitle) playerTitle.textContent = song.title;
    if (playerArtist) playerArtist.textContent = song.artist_name || 'Đang cập nhật';
    
    currentAudio.play().then(() => {
        isPlaying = true;
        updatePlayBtnIcon();
    }).catch(err => {
        console.error("Lỗi phát audio:", err);
    });

    // Tăng lượt nghe trong CSDL (Gửi request ngầm nếu cần)
    if (song.id) {
        fetch(`api_view.php?id=${song.id}`).catch(() => {});
    }
}

// Bật / Dừng phát
function togglePlayPause() {
    if (!currentAudio.src) return;
    if (isPlaying) {
        currentAudio.pause();
        isPlaying = false;
    } else {
        currentAudio.play();
        isPlaying = true;
    }
    updatePlayBtnIcon();
}

function updatePlayBtnIcon() {
    if (!playPauseIcon) return;
    if (isPlaying) {
        playPauseIcon.classList.remove('bi-play-fill');
        playPauseIcon.classList.add('bi-pause-fill');
    } else {
        playPauseIcon.classList.remove('bi-pause-fill');
        playPauseIcon.classList.add('bi-play-fill');
    }
}

// Sự kiện cập nhật tiến độ audio
currentAudio.addEventListener('timeupdate', () => {
    if (currentAudio.duration) {
        const percent = (currentAudio.currentTime / currentAudio.duration) * 100;
        if (progressFilled) progressFilled.style.width = `${percent}%`;
        if (currentTimeEl) currentTimeEl.textContent = formatTime(currentAudio.currentTime);
        if (durationEl) durationEl.textContent = formatTime(currentAudio.duration);
    }
});

// Khi bài hát kết thúc
currentAudio.addEventListener('ended', () => {
    if (isLoop) {
        currentAudio.currentTime = 0;
        currentAudio.play();
    } else {
        playNextTrack();
    }
});

// Chuyển bài kế tiếp
function playNextTrack() {
    if (playlist.length > 0) {
        currentTrackIndex = (currentTrackIndex + 1) % playlist.length;
        playSong(playlist[currentTrackIndex]);
    } else {
        isPlaying = false;
        updatePlayBtnIcon();
    }
}

// Quay lại bài trước
function playPrevTrack() {
    if (playlist.length > 0) {
        currentTrackIndex = (currentTrackIndex - 1 + playlist.length) % playlist.length;
        playSong(playlist[currentTrackIndex]);
    }
}

// Tua nhạc khi click lên thanh thời gian
if (progressBar) {
    progressBar.addEventListener('click', (e) => {
        const rect = progressBar.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const width = rect.width;
        if (currentAudio.duration) {
            currentAudio.currentTime = (clickX / width) * currentAudio.duration;
        }
    });
}

// Điều chỉnh âm lượng
if (volumeSlider) {
    volumeSlider.addEventListener('input', (e) => {
        currentAudio.volume = e.target.value;
    });
}

// Lặp lại bài hát
if (loopBtn) {
    loopBtn.addEventListener('click', () => {
        isLoop = !isLoop;
        loopBtn.style.color = isLoop ? 'var(--primary-color)' : 'var(--text-muted)';
    });
}

if (playPauseBtn) playPauseBtn.addEventListener('click', togglePlayPause);
if (nextBtn) nextBtn.addEventListener('click', playNextTrack);
if (prevBtn) prevBtn.addEventListener('click', playPrevTrack);

// Lắng nghe click các nút Play trên các thẻ bài hát
document.addEventListener('DOMContentLoaded', () => {
    const playButtons = document.querySelectorAll('.js-play-song');
    playButtons.forEach((btn, index) => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const songData = {
                id: btn.dataset.id,
                title: btn.dataset.title,
                artist_name: btn.dataset.artist,
                file_path: btn.dataset.file,
                thumbnail: btn.dataset.thumb
            };
            
            // Cập nhật danh sách phát hiện tại
            playlist = Array.from(playButtons).map(b => ({
                id: b.dataset.id,
                title: b.dataset.title,
                artist_name: b.dataset.artist,
                file_path: b.dataset.file,
                thumbnail: b.dataset.thumb
            }));
            currentTrackIndex = index;

            playSong(songData);
        });
    });
});

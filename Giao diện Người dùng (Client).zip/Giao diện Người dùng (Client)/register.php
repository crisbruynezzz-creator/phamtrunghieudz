<?php
/**
 * register.php - Trang đăng ký thành viên mới
 */
require_once __DIR__ . '/config/database.php';

if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    if (empty($fullname) || empty($username) || empty($email) || empty($password)) {
        $error = 'Vui lòng điền đầy đủ tất cả thông tin!';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Định dạng email không hợp lệ!';
    } elseif (strlen($password) < 6) {
        $error = 'Mật khẩu phải chứa ít nhất 6 ký tự!';
    } elseif ($password !== $password_confirm) {
        $error = 'Mật khẩu xác nhận không trùng khớp!';
    } else {
        // Kiểm tra xem username hoặc email đã tồn tại chưa
        $stmtCheck = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmtCheck->execute([$username, $email]);
        if ($stmtCheck->rowCount() > 0) {
            $error = 'Tên đăng nhập hoặc Email đã được sử dụng!';
        } else {
            // Mã hóa mật khẩu bảo mật
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            $stmtInsert = $pdo->prepare("
                INSERT INTO users (username, password, fullname, email, role) 
                VALUES (?, ?, ?, ?, 'user')
            ");
            $stmtInsert->execute([$username, $hashedPassword, $fullname, $email]);
            $success = 'Đăng ký tài khoản thành công! Bạn có thể đăng nhập ngay bây giờ.';
        }
    }
}

$pageTitle = "Đăng Ký Tài Khoản";
include_once __DIR__ . '/includes/header.php';
?>

<div class="row justify-content-center py-5">
    <div class="col-md-7 col-lg-5">
        <div class="card bg-card border-secondary p-4 p-md-5 rounded-4 shadow">
            <div class="text-center mb-4">
                <i class="bi bi-person-plus-fill text-success fs-1"></i>
                <h3 class="fw-bold text-white mt-2">Đăng Ký Tài Khoản</h3>
                <p class="text-muted small">Tạo tài khoản để nghe nhạc không giới hạn</p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger py-2 px-3 small mb-3"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="alert alert-success py-2 px-3 small mb-3">
                    <?= htmlspecialchars($success) ?>
                    <div class="mt-2"><a href="login.php" class="btn btn-sm btn-success">Đến trang Đăng Nhập</a></div>
                </div>
            <?php else: ?>
                <form action="register.php" method="POST">
                    <div class="mb-3">
                        <label class="form-label text-light">Họ và tên</label>
                        <input type="text" name="fullname" class="form-control form-control-dark" placeholder="Nguyễn Văn A" required value="<?= htmlspecialchars($_POST['fullname'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-light">Tên đăng nhập (Username)</label>
                        <input type="text" name="username" class="form-control form-control-dark" placeholder="nguyenvana" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-light">Email</label>
                        <input type="email" name="email" class="form-control form-control-dark" placeholder="vana@gmail.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-light">Mật khẩu (Tối thiểu 6 ký tự)</label>
                        <input type="password" name="password" class="form-control form-control-dark" placeholder="••••••••" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label text-light">Nhập lại mật khẩu</label>
                        <input type="password" name="password_confirm" class="form-control form-control-dark" placeholder="••••••••" required>
                    </div>

                    <button type="submit" class="btn btn-primary-custom w-100 py-2 mb-3">
                        Đăng Ký
                    </button>
                </form>
            <?php endif; ?>

            <div class="text-center text-muted small">
                Đã có tài khoản? <a href="login.php" class="text-success text-decoration-none fw-semibold">Đăng nhập</a>
            </div>
        </div>
    </div>
</div>

<?php include_once __DIR__ . '/includes/footer.php'; ?>

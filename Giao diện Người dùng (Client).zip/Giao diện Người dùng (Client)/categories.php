<?php
/**
 * categories.php - Danh mục thể loại và bài hát theo thể loại
 */
require_once __DIR__ . '/config/database.php';

$cat_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Lấy danh sách tất cả thể loại kèm số lượng bài hát
$stmtCats = $pdo->query("
    SELECT c.*, COUNT(s.id) AS total_songs 
    FROM categories c
    LEFT JOIN songs s ON c.id = s.category_id
    GROUP BY c.id
    ORDER BY c.name ASC
");
$categories = $stmtCats->fetchAll();

// Nếu có chọn 1 thể loại cụ thể
$selectedCategory = null;
if ($cat_id > 0) {
    $stmtSelected = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
    $stmtSelected->execute([$cat_id]);
    $selectedCategory = $stmtSelected->fetch();

    $stmtSongs = $pdo->prepare("
        SELECT s.*, a.name AS artist_name 
        FROM songs s
        JOIN artists a ON s.artist_id = a.id
        WHERE s.category_id = ?
        ORDER BY s.id DESC
    ");
    $stmtSongs->execute([$cat_id]);
    $songs = $stmtSongs->fetchAll();
} else {
    // Mặc định lấy toàn bộ bài hát
    $stmtSongs = $pdo->query("
        SELECT s.*, a.name AS artist_name, c.name AS category_name 
        FROM songs s
        JOIN artists a ON s.artist_id = a.id
        JOIN categories c ON s.category_id = c.id
        ORDER BY s.id DESC
    ");
    $songs = $stmtSongs->fetchAll();
}

$pageTitle = $selectedCategory ? "Thể loại: " . $selectedCategory['name'] : "Thể Loại Nhạc";
include_once __DIR__ . '/includes/header.php';
?>

<div class="row mb-4">
    <div class="col-12">
        <h3 class="fw-bold mb-3"><i class="bi bi-grid-fill text-success me-2"></i>Khám Phá Thể Loại</h3>
        <!-- Danh sách nút bấm thể loại -->
        <div class="d-flex flex-wrap gap-2 mb-4">
            <a href="categories.php" class="btn <?= ($cat_id == 0) ? 'btn-success' : 'btn-outline-custom' ?> btn-sm">
                Tất Cả Thể Loại
            </a>
            <?php foreach ($categories as $cat): ?>
                <a href="categories.php?id=<?= $cat['id'] ?>" class="btn <?= ($cat_id == $cat['id']) ? 'btn-success' : 'btn-outline-custom' ?> btn-sm">
                    <?= htmlspecialchars($cat['name']) ?> (<?= $cat['total_songs'] ?>)
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php if ($selectedCategory): ?>
    <div class="alert alert-dark border-secondary p-3 mb-4 rounded-3">
        <h5 class="fw-bold text-success mb-1"><?= htmlspecialchars($selectedCategory['name']) ?></h5>
        <p class="mb-0 text-muted small"><?= htmlspecialchars($selectedCategory['description'] ?? 'Các bài hát thuộc thể loại ' . $selectedCategory['name']) ?></p>
    </div>
<?php endif; ?>

<!-- Danh sách bài hát -->
<div class="row row-cols-2 row-cols-md-3 row-cols-lg-6 g-3 mb-5">
    <?php if (empty($songs)): ?>
        <div class="col-12 w-100 text-center py-5">
            <p class="text-muted">Chưa có bài hát nào trong thể loại này.</p>
        </div>
    <?php else: ?>
        <?php foreach ($songs as $song): ?>
            <div class="col">
                <div class="music-card">
                    <div class="card-img-wrapper">
                        <img src="<?= htmlspecialchars($song['thumbnail']) ?>" alt="<?= htmlspecialchars($song['title']) ?>">
                        <button class="play-btn-overlay js-play-song" 
                                data-id="<?= $song['id'] ?>"
                                data-title="<?= htmlspecialchars($song['title']) ?>"
                                data-artist="<?= htmlspecialchars($song['artist_name']) ?>"
                                data-file="<?= htmlspecialchars($song['file_path']) ?>"
                                data-thumb="<?= htmlspecialchars($song['thumbnail']) ?>">
                            <i class="bi bi-play-fill fs-5"></i>
                        </button>
                    </div>
                    <h6 class="card-title" title="<?= htmlspecialchars($song['title']) ?>">
                        <a href="song.php?id=<?= $song['id'] ?>" class="text-white text-decoration-none">
                            <?= htmlspecialchars($song['title']) ?>
                        </a>
                    </h6>
                    <p class="card-subtitle"><?= htmlspecialchars($song['artist_name']) ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php include_once __DIR__ . '/includes/footer.php'; ?>
